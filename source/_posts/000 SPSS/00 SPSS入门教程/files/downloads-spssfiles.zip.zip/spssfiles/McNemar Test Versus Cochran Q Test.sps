﻿*SPSS McNemar Test Result Compared to Cochran's Q Test Result for Two Variables.

*1. Create Test Data.

data list free/v1 to v36.
begin data
 1 1 0 0 1 0 1 1 1 1 1 1 1 1 1 0 1 1 1 1 0 1 1 1 1 1 0 1 1 1 1 1 0 0 0 1
 1 1 0 0 1 0 1 1 0 0 0 0 0 1 0 0 1 0 1 1 1 0 1 1 0 1 1 1 1 1 1 1 0 0 0 1
end data.

flip.

*2. Standard McNemar Test.

NPAR TESTS
  /MCNEMAR=var001 WITH var002 (PAIRED)
  /MISSING ANALYSIS.

*3. Exact McNemar Test (requires SPSS Exact Tests Option).

NPAR TESTS
  /MCNEMAR=var001 WITH var002 (PAIRED)
  /MISSING ANALYSIS
  /METHOD=EXACT TIMER(5).

*4. Standard Cochran Q Test.

NPAR TESTS
  /COCHRAN=var001 var002
  /MISSING LISTWISE.

*5. Exact Cochran Q Test (requires SPSS Exact Tests Option).

NPAR TESTS
  /COCHRAN=var001 var002
  /MISSING LISTWISE
  /METHOD=EXACT TIMER(5).

*Conclusion: McNemar test always comes up with exact 2-tailed p-value. 

*This (identical) p-value is obtained from Cochran's test only if METHOD = EXACT is added to command. This requires the SPSS exact tests option to be purchased and installed.

*Run SHOW LICENSE. if you're not sure whether you have this option at your disposal. It's probably included in student and trial licenses.

*Without METHOD = EXACT Cochran's test is based on an approximate ("asymp" for "asymptotic") p-value and McNemar's test uses the exact p-value, explaining the difference.
