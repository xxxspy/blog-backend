*Create test data for 200 cases.

data list free/id.
begin data
0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    
0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    
0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    
0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    
end data.

compute id = $casenum.

*Compute 4 wave variables.

set seed 1.
do repeat #wave = wave1 to wave4 / #perc = .9 .85 .7 .8.
compute #wave = rv.bernoulli(#perc).
end repeat.

value labels wave1 to wave4 0 'Didn''t participate' 1 'Participated'.

*Declare new dataset.

dataset declare response_patterns.

*Create dataset with each different response pattern and its frequency.

aggregate outfile response_patterns
/break wave1 to wave4
/ofreq = n.

dataset activate response_patterns.

*ofreq (short for observed frequency) represents number of cases for each pattern.

weight by ofreq.

*Add total frequency (n = 200) to data.

aggregate outfile * mode addvariables
/tfreq = n.

*Compute percentage for each response pattern.

compute operc = (ofreq / tfreq) * 100.

formats operc(pct4).

*Sort response patterns by descending percentage with which they occur.

sort cases by operc(d).
