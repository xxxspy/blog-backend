*Set up test data.

data list free/id.
begin data
0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    
0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    0 0 0 0 0    
end data.

set seed 1.

if($casenum = 1) id = 1.
if($casenum > 1) id = lag(id) + rv.bernoulli(.2).

compute entry = datesum(date.dmy(1,7,2015),trunc(rv.uniform(20,200)),'days').
formats entry(date11).

sort cases by id entry.

*Test data ready. Solution starts here.

if($casenum = 1 or id <> lag(id)) cdate = entry.
formats cdate(date11).
execute.

do if (datediff(entry,lag(cdate),'days') < 30).
if($casenum <> 1 and missing(cdate)) cdate = lag(cdate).
else.
if(missing(cdate)) cdate = entry.
end if.
execute.

compute flag = (cdate = entry).
execute.