﻿*Find number of variables in active dataset. Note: requires SPSS Python Essentials properly installed and running.

begin program.
import spss
varcnt = spss.GetVariableCount()
print "There's %d variables in the active dataset"%varcnt
end program