﻿*Create 1,000 empty cases.

input program.
loop id = 1 to 1000.
end case.
end loop.
end file.
end input program.

*Create latent factor.

compute latent = rnd(rv.uniform(1,10)).

*Create two correlated Likert items as observable indicators of latent factor.

compute likert_1 = rv.binom(4,(.1 * latent)) + 1.
compute likert_2 = rv.binom(4,(.1 * latent)) + 1.

value labels likert_1 likert_2 1 'Very bad' 5 'Very good'.

*Check crosstab.

crosstabs likert_1 by likert_2.

*Check correlation.

correlations likert_1 with likert_2.
