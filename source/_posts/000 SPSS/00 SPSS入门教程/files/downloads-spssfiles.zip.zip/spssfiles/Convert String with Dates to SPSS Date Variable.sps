﻿*Set up test data.

data list free/mydate(a9).
begin data
01NOV2016
15OCT2017
end data.

*Create new date variable as string.

string newdate(a11).

*Add day, month, year from old string to new string and separate these components with dashes. Note: we could put the entire command on 1 line.
*However, the whole thing is more readable, manageable and debuggable by adding some line breaks between components.

compute newdate = concat(
char.substr(mydate,1,2),   /*start at character 1, extract 2 characters (day)
'-',
char.substr(mydate,3,3),  /*start at character 3, extract 3 characters (month)
'-',
char.substr(mydate,6,4)  /*start at character 6, extract 4 characters (year)
).

*Check if result is as desired.

execute.

*Convert stringdate with dashes to SPSS date variable.

alter type newdate (date11).

*Since ALTER TYPE may result in system missing values without error or warning, check if (valid N == casecount). 
*If not, check original string dates for empty string values or other issues. If needed, use REPLACE function for correcting month abbreviations.

descriptives newdate.

*Done.
