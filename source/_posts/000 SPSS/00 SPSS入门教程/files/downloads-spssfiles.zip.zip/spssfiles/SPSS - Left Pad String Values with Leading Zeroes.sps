﻿*Approach 1: don't convert string to numeric.

data list free/id(a4).
begin data
1 2 3 4 10 243 5427
end data.

*Increase length of string so left padded numbers will fit into it.

alter type id(a10).

*Keep adding a leading zero to values until they contain 10 characters.

loop.
compute id = concat('0',rtrim(id)).
end loop if char.length(id) = 10.
execute.

*Done with approach 1.



*Approach 2: convert string to numeric.

data list free/id(a4).
begin data
1 2 3 4 10 243 5427
end data.

*Convert to numeric.

alter type id(f4).

*Check whether no system missings occur due to ALTER TYPE.

descriptives id.

*Show numbers with leading zeroes.

formats id(n10).

*Done with approach 2.
