*Create test data.

data list free/id.
begin data
1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20
end data.

*Compute birthday.

set rng mc seed 1.
compute bday = datesum(date.dmy(1,1,1990),trunc(rv.uniform(0,2000)),'days').
formats bday(date11).

*Inspect birthday.

frequencies bday/format notable/histogram.

*Compute wave variables.

do repeat #wave = wave1 to wave5 / #ind = 1 to 5.
compute #wave = datesum(date.dmy(1,1,2016),#ind * 90,'days').
end repeat.
formats wave1 to wave5(date11).
execute.

*Solution starts here.

compute targetwave = 0.

do repeat #wave = wave1 to wave5 / #ind = 1 to 5.
if (targetwave = 0 and datediff(#wave,bday,'years') >= 25) targetwave = #ind.
end repeat.
execute.
