﻿*1. Create test data.

data list free/ID Month Match_Sequence.
begin data.
1 3 1 
1 4 2 
1 10 3
end data.

*2. Option 1: reverse case order.

compute record = $casenum.

sort cases by record(d).

compute outcome =  lag(month) - month.
execute.

sort cases by record(a).

*3. Done. Delete new variables for option 2.

delete variables record outcome.

*4. Option 2: create lead variable with SPSS CREATE command.

create next_month = lead(month,1).

compute outcome = next_month - month.
execute.

*5. Done again.
